package com.newluxes.lawful;

public class Law {
    public int Id;
    public String Artigo;

    public Law(String Artigo){
        this.Artigo = Artigo;
    }

    public Law(){

    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getArtigo() {
        return Artigo;
    }

    public void setArtigo(String artigo) {
        Artigo = artigo;
    }
}
