package com.newluxes.lawful;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;


public class layout_item extends AppCompatActivity {

    TextView mRes2;
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_item);

        mRes2 = (TextView) findViewById(R.id.mArt);
        Intent intent = getIntent();

        String art;

        art = intent.getStringExtra("Texto");

        mRes2.setText(art);
    }
}