package com.newluxes.lawful.adapter;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;

import com.newluxes.lawful.Law;
import com.newluxes.lawful.R;

import java.util.List;


class SeachViewHolder extends RecyclerView.ViewHolder{

    public TextView artigo;
    public SeachViewHolder(@NonNull View itemView) {

        super(itemView);
        artigo = (TextView) itemView.findViewById(R.id.mArt);
    }
}

public class SearchAdapter extends RecyclerView.Adapter<SeachViewHolder> {

    private Context mContext;
    private List<Law> mLaws;

    public SearchAdapter(Context context, List<Law> laws) {
        mContext = context;
        mLaws = laws;
    }

    @NonNull
    @Override
    public SeachViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.activity_layout_item, parent, false);
        return new SeachViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SeachViewHolder holder, int position) {

        holder.artigo.setText(mLaws.get(position).getArtigo());
    }

    @Override
    public int getItemCount() {
        return mLaws.size();
    }
}

