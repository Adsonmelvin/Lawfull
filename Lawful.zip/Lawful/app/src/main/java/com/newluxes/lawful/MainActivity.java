package com.newluxes.lawful;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mancj.materialsearchbar.MaterialSearchBar;
import com.newluxes.lawful.adapter.SearchAdapter;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {


    com.mancj.materialsearchbar.MaterialSearchBar mSearchView;

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    SearchAdapter mAdapter;
    DatabaseOpenHelper mDatabase;

    List<String> suggestList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mSearchView = (com.mancj.materialsearchbar.MaterialSearchBar) findViewById(R.id.search_bar);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycle_search);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setHasFixedSize(true);


        mDatabase = new DatabaseOpenHelper(this);

        mSearchView.setHint("Search");
        mSearchView.setElevation(10);

        loadSuggestList();

        mSearchView.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                List<String> suggest = new ArrayList<>();
                for (String search: suggestList){
                    if (search.toLowerCase().contains(mSearchView.getText().toLowerCase()))
                        suggest.add(search);
                }
                mSearchView.setLastSuggestions(suggest);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });



        mSearchView.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {
                if (!enabled)
                    mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                startSearch(text.toString());
            }

            @Override
            public void onButtonClicked(int buttonCode) {

            }
        });

        mAdapter = new SearchAdapter(this, mDatabase.getLaw());
        mRecyclerView.setAdapter(mAdapter);


    }

    private void loadSuggestList() {
        suggestList = mDatabase.getArtigos();
        mSearchView.setLastSuggestions(suggestList);

    }

    private void startSearch(String text) {
        mAdapter = new SearchAdapter(this,mDatabase.getLawbyArtigo(text));
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Sair:
                finish();
                break;

            case R.id.Ajuda:

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("AJUDA\n" +
                        "\nEsta aplicação  abrange somente" +
                        "\nO Codigo Civil\n" +
                        "\n" +
                        "Para poder pesquisar artigos, vá ao\n“Campo de pesquisa” e digite o artigo que deseja procurar\n, de seguida clique em pesquisar no teclado\n " +
                        "\nExemplo de uma pesquisa:\n" +
                        "fixar\n" +
                        "\n" +
                        "Para poder pesquisar por artigos especificos, vá ao\n Campo “Procurar por Artigo” no menu e digite o numero do artigo que deseja procurar\n, de seguida clique em buscar \n " +
                        "\nExemplo de procurar por artigo:\n" +
                        "23\n" + "\n Para partilhar o artigo: Clica no butao de partilhar\n" + "\n Se estiver com alguma dificuldade contacte a equipe de suporte: \n" + "- lawfull.corporation@gmail.com");
                AlertDialog alert = builder.create();
                alert.show();
                break;

            case R.id.PorArt:

                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(intent);

                break;

            case R.id.Sobre:
                AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
                builder2.setMessage("SOBRE A APLICAÇÃO\n" +
                        "\nLawfull 2.0v \n" +
                        "\nCodigo Civil : 84 artigos disponiveis \n" +
                        "© Copyright 2022 | Adson M. G. Cochelane\n" +
                        "(Adsongilberto@gmail.com)\n");
                AlertDialog alert2 = builder2.create();
                alert2.show();
                break;

            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}