package com.newluxes.lawful;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseOpenHelper extends SQLiteAssetHelper {

    private static final String DATABASE_NAME="Lawfull.db";
    private static final int DATABASE_VERSION= 1;

    //CONSTRUTOR

    public DatabaseOpenHelper (Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    public List<Law> getLaw(){

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"Artigo"};
        String tableName = "Table1";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<Law> result = new ArrayList<>();

        if (cursor.moveToFirst()){
            do {
                Law law = new Law();
                law.setArtigo(cursor.getString(cursor.getColumnIndexOrThrow("Artigo")));
                        result.add(law );
            }while (cursor.moveToNext());
        }
        return result;
    }

    public List<String> getArtigos() {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"Artigo"};
        String tableName = "Table1";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, null, null, null, null, null);
        List<String> result = new ArrayList<>();

        if (cursor.moveToFirst()){
            do {
                result.add(cursor.getString(cursor.getColumnIndexOrThrow("Artigo")));
            }while (cursor.moveToNext());
        }
        return result;
    }

    public List<Law> getLawbyArtigo(String Artigo){

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"Artigo"};
        String tableName = "Table1";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlSelect, "Artigo LIKE ?", new String[] {"%" + Artigo + "%"}, null, null, null);
        List<Law> result = new ArrayList<>();

        if (cursor.moveToFirst()){
            do {
                Law law = new Law();
                law.setArtigo(cursor.getString(cursor.getColumnIndexOrThrow("Artigo")));
                result.add(law );
            }while (cursor.moveToNext());
        }
        return result;
    }
}
