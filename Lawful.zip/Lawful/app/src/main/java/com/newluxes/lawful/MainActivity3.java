package com.newluxes.lawful;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity3 extends AppCompatActivity {

    EditText mArtigo;
    Button mMostar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        mArtigo = (EditText) findViewById(R.id.mInput);
        mMostar = (Button) findViewById(R.id.mbuscar);

        mMostar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                try {
                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getApplicationContext());
                    databaseAccess.open();
                    int n = Integer.parseInt(mArtigo.getText().toString());
                    String artigo = databaseAccess.getArtigoNr(n);


                    if (artigo.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "O Artigo Pesquisado Não Existe.", Toast.LENGTH_SHORT).show();

                    } else {
                        Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                        intent.putExtra("Texto", artigo);
                        startActivity(intent);
                        databaseAccess.close();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Adicione numero de um artigo", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}