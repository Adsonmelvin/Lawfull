package com.newluxes.lawful;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity2 extends AppCompatActivity {

    TextView mRes1;
    FloatingActionButton mShare;
    Button mBtmais, mBtmenos;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mRes1 = (TextView) findViewById(R.id.Res2);
        mShare = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        mBtmais = (Button) findViewById(R.id.aumentar);
        mBtmenos = (Button) findViewById(R.id.diminuir);

        final int[] TxtSize = {20};


        Intent intent = getIntent();

        String art;

        art = intent.getStringExtra("Texto");

        String msg = art + "\n \n Artigo Retirado do Codigo Civil";

        mRes1.setText(art);

        mShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                try {
                    Intent intent1 = new Intent(Intent.ACTION_SEND);
                    intent1.putExtra(Intent.EXTRA_TEXT, msg);
                    intent1.setType("text/plain");
                    intent1.setPackage("com.whatsapp");
                    startActivity(intent1);
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "WhatsApp nao esta Instalado", Toast.LENGTH_SHORT).show();
                }

            }
        });

        mBtmais.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (36 >= TxtSize[0]) {
                    TxtSize[0] += 2;

                    mRes1.setTextSize(TxtSize[0]);

                }

            }
        });

        mBtmenos.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (16 <= TxtSize[0]) {
                    TxtSize[0] -= 2;

                    mRes1.setTextSize(TxtSize[0]);

                }
            }
        });

    }
}